//
//  ViewController.swift
//  ArtworkFinder
//
//  Created by CR3A7OR on 04/01/2021.
//

import UIKit
import MapKit
import CoreLocation
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, MKMapViewDelegate, CLLocationManagerDelegate {
    
    /* Instantiate a context so we can access the core data through a view container */
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    /* Create an instance to manage user's location */
    var locationManager = CLLocationManager()
    
    /* Used to access decoded structure from within closure*/
    var artWork:AllArtworks? = nil
    
    /* Outlet to the map view */
    @IBOutlet weak var myMap: MKMapView!
    
    /*
     * Function gets all unique locations from the JSON data by iterating through the art works and checking their location value pair
     * Then checks all artworks and groups them by location to later display under section headers
     */
    var listLoc:[Locations?] = []
    var artOnSite:[[Artwork?]] = []
    func getLocations() {
        var currentIndex = 0
        for art in artWork!.artworks  {
            /* Check if artwork is enabled else do not add to array */
            if art.enabled != "1" {
                continue
            }
            /* Define an object with the new Locations structure */
            let locationItem:Locations? = Locations(title:art.locationNotes ?? "none", lat:art.lat, lon:art.long, locPoint: art.location, distance: 0)
            
            var duplicate = false
            /* Check if value pair is not already saved in array to prevent duplicates */
            for loc in listLoc {
                
                //if (art.lat == loc?.lat && art.long == loc?.lon) {
                if (art.location == loc?.locPoint) {
                    duplicate = true
                }
            }
 
            if !duplicate {
            /* Appen the location to the array to be displayed later */
             listLoc.append(locationItem)
                artOnSite.append([])
                /* Append a empty list to represent new location and for all artworks iterate through and check if location value pair matches current location  */
                for art in artWork!.artworks{
                    //if art.lat == locationItem?.lat && art.long == locationItem?.lon {
                    if (art.location == locationItem?.locPoint) {
                        artOnSite[currentIndex].append(art)
                    }
                }
                
                
              currentIndex += 1
            }

        }
       
    }
   
    /* Create outlet for table view  */
    @IBOutlet var theTable: UITableView!
    var currentCell = -1
    /* Function is called when creating the amount of rows in each section */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        /* Present all artwork for the current section based on location  */
        return artOnSite[section].count
    }
    
    /* Function is called when populating header values of section */
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        /* Label each section with the unique location stored in array */
        return listLoc[section]?.locPoint
    }
    
    /* Function is called when creating the amount of sections in table */
    func numberOfSections(in tableView: UITableView) -> Int {
        /* Number of sections is equal to number of locations stored */
        return listLoc.count
    }
    
    /* Function is called when populating the context of each cell */
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*  Instantiate variable as a cell from the table view so we can change the view style */
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        
        /* Assign cell text as the artwork name found at the current index row and section */
        cell.textLabel?.text = artOnSite[indexPath.section][indexPath.row]?.title ?? "no title"
       
        /* Assign cell sub-text as the artwork artist found at the current index row and section */
        cell.detailTextLabel?.text = artOnSite[indexPath.section][indexPath.row]?.artist ?? "no artist"
        
        return cell
    }
    
    /* Boolean flag to represent if this is first run of program*/
    var firstRun = false
    override func viewDidLoad() {
        super.viewDidLoad()
        /* Set initial location as the ashton building and centre map towards it acting as a default location */
        let initialLoc = CLLocation(latitude: 53.406566, longitude: -2.966531)
        myMap.centerToLocation(initialLoc)
        // Do any additional setup after loading the view.
        
        /* We want messages about location */
        locationManager.delegate = self as CLLocationManagerDelegate
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        /* Ask the user for permission to get their location */
        locationManager.requestWhenInUseAuthorization()
        /* Start receiving those messages (if we’re allowed to) */
        locationManager.startUpdatingLocation()
        
        /* Show user's current location on map with blue dot */
        myMap.showsUserLocation = true
        firstRun = true
        
        /*FETCH REQUEST FOR DATA FROM CORE DATA
        let fetchRequest = NSFetchRequest<CoreArts>(entityName: "CoreArts")
        do {
            let tests = try self.context.fetch(fetchRequest)
            for test in tests {
                print(test.title!)
            }
            
        }
        catch{
            print("Retrieving Data Erro")
        }
         */
         
        /* Call to function to empty entityin Core data */
        self.deleteAllData("CoreArts")
        /* Decode the API into JSON format to find the key value pairs  */
        if let url = URL(string: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/artworksOnCampus/data.php?class=artworks") {
            /* Create a swift closure  */
            let session = URLSession.shared
            session.dataTask(with: url) { (data, response, err) in
                guard let jsonData = data else {
                        return
                }
                do {
                    let decoder = JSONDecoder()
                    /* Access the decoded structure and then point artwork variable at structure so we can access the data*/
                    let reportList = try decoder.decode(AllArtworks.self, from: jsonData)
                    self.artWork = reportList
                    /* For all the artwork from the data structure save it to core data matching the value pairs by the attributes in the entity  */
                    for arts in self.artWork!.artworks {
                        let art = CoreArts(context: self.context)
                        art.id = arts.id
                        art.title = arts.title
                        art.artist = arts.artist
                        art.yearOfWork = arts.yearOfWork
                        art.type = arts.type
                        art.information = arts.Information
                        art.lat = arts.lat
                        art.long = arts.long
                        art.location = arts.location
                        art.locationNotes = arts.locationNotes
                        art.fileName = arts.fileName
                        art.lastModified = arts.lastModified
                        art.enabled = arts.enabled
                        
                        do {
                            try self.context.save()
                        }catch{}
                        
                    }
                    /* Call function from main queue*/
                    DispatchQueue.main.async {
                        self.updateTheTable()
                    }
                /* Catch any errors with decoding the JSON and print them */
                } catch let jsonErr {
                        print("Error decoding JSON", jsonErr)
                }
            }.resume()
        }
        
     }
    
    /* Function calls a function to find locations from JSON data
     * Calls a function to populate the map view with annotation pins of the unique locations
     * Reloads the table view
     */
    func updateTheTable() {
        getLocations()
        showPins()
        theTable.reloadData()

     }
    
    /* Function which clears all data saved in entity from Core Data */
    func deleteAllData(_ entity:String) {
        /* Create fetch request with the entity passed by parameter */
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        fetchRequest.returnsObjectsAsFaults = false
        do {
            /* Store results of fetch in mutable array as an NSManagedObject */
            let results = try context.fetch(fetchRequest)
            /* For every NSManagedObject in the array delete it from Core Data */
            for result in results {
                guard let resultData = result as? NSManagedObject else {continue}
                context.delete(resultData)
             
                
            }
        /* Catch and print error if there is one */
        } catch let error {
            print("Deleting entity producded error:", error)
        }
    }
    
    /* Function manages everytrhing when the user's location updates */
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        /* Get the first location (ignore any others).
         * Get the longtitude and latitude
         * Set the span of the map view
         * Set the centred location to the user
         */
        let locationOfUser = locations[0]
        let latitude = locationOfUser.coordinate.latitude
        let longitude = locationOfUser.coordinate.longitude
        let latDelta: CLLocationDegrees = 0.002
        let lonDelta: CLLocationDegrees = 0.002
        /* Get the current span set bby the user through interaction with the map view*/
        let currentSpan = self.myMap.region.span
        let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: lonDelta)
        let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let locationcoord = CLLocation(latitude: latitude, longitude: longitude)
        /* If this is not the initial run then we use the user's span through interaction allowing them to zoom into the map whilst keeping it centred
         * Else use the span set prior using the longtitude and latitude
         */
        if !firstRun {
            let region = MKCoordinateRegion(center: location, span: currentSpan)
            self.myMap.setRegion(region, animated: true)
            
        }
        else {
            firstRun = false
            let region = MKCoordinateRegion(center: location, span: span)
            self.myMap.setRegion(region, animated: true)
        }
        
        /* For every location saved in the array work out the distance from the user and then save it into the array under value pair distance */
        for i in 0..<listLoc.count {
            guard let lat = listLoc[i]?.lat else { return }
            guard let lon = listLoc[i]?.lon else { return }
            guard let latitude = Double(lat) else { return }
            guard let longitude = Double(lon) else { return }
            let coordinate = CLLocation(latitude: latitude, longitude: longitude)
            let metersDistance = coordinate.distance(from: locationcoord)
            listLoc[i]?.distance = metersDistance
            
        }
        
        /* Sort the array by the distance value pair */
        listLoc = listLoc.sorted(by: {$0!.distance < $1!.distance})
        /* Call function to correctly show art after section name re order */
        orderArt()
        /* Iterate through all locations in array and check which one matches sectionName selected by user to keep focus on it when table updates */
        for j in 0..<listLoc.count {
            if listLoc[j]?.locPoint == sectionName {
                position = j
                
            }
        }
        /* reload table view */
        theTable.reloadData()
    }
    /* Function matches all artowkrs to the corresponding section effectivly reorderinbg the array to be correctly presented on the table view */
    func orderArt() {
        /* Empty array to allow for new correctly ordered artworks */
        artOnSite.removeAll()
        var currentIndex = 0
            for loc in listLoc {
                artOnSite.append([])
                /* Append a empty list to represent new location and for all artworks iterate through and check if location value pair matches current location and append it onto the array  */
                for art in artWork!.artworks{
                    /* Check if artwork is enabled else do not add to array */
                    if art.enabled != "1" {
                        continue
                    }
                    //if art.lat == loc?.lat && art.long == loc?.lon {
                    if (art.location == loc?.locPoint) {
                        
                        artOnSite[currentIndex].append(art)
                    }
               
                }
                /* Increment counter */
                currentIndex += 1
           }
        
    }
    
    /* Used to manage and represent the current annotation selected by the user */
    var position = -1
    var sectionName: String = ""
    /* Function handles the aesthetic of a section everytime it appears on the table view to differentiate the selection  */
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header = view as! UITableViewHeaderFooterView
        /* Check if the current section shown is the same as the section selected by the user through annotation */
        if section == position {
            /* Change colour of section to red background and white text */
            view.tintColor = UIColor.red
            header.textLabel?.textColor = UIColor.white
            
        }
        else {
            /* Change colour of section to light grey background and black text */
            view.tintColor = UIColor.lightGray
            header.textLabel?.textColor = UIColor.white
        }
    }
    
    
    /* Function called when user selects annotation and the table view will scroll to the corresponding section  */
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        myMap.delegate = self
        //let temp2 = view.annotation?.title!!
        /* Store the annotation's coordinate in a variable */
        let temp = view.annotation?.coordinate
    
        var indexLoc = 0
        /* Get the coordinate for every location stored in the array  */
        for loc in listLoc {
            guard let lat = loc?.lat else { return }
            guard let lon = loc?.lon else { return }
            guard let latitude = Double(lat) else { return }
            guard let longitude = Double(lon) else { return }
            let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            /* Compare the annotations long and lat with the locations long and  lat  */
            if temp?.latitude == coordinate.latitude && temp?.longitude == coordinate.longitude {
                /* Store the current index position and the location name */
                position = indexLoc
                sectionName = loc!.locPoint
                /* Scroll the table view to the matching section index to present the location to the user */
                theTable.scrollToRow(at: IndexPath(row:0, section:indexLoc), at: UITableView.ScrollPosition.top, animated: true)
                //let indexPath: IndexPath = IndexPath(row:0, section:indexLoc)
                /* Reload table view */
                theTable.reloadData()
                break
                        
            }
            indexLoc += 1
        }
    }
    
    /* Function called when user deselects annotation then reset the colour of the section by resetting managing variables  */
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        position = -1
        sectionName = ""
        theTable.reloadData()
    }
    
  
    var currentPlace = 0
    /* Function will show annotations on the map view for every unique location stored in array */
    func showPins() {
        guard currentPlace != -1 else { return }
        /* Iterate through all of array and retrieve name, lat and long value pairs
         * Map them on the map view by creating a coordinate and then give the annotation a title of the location place
         */
        while listLoc.count > currentPlace {
            guard let name = listLoc[currentPlace]?.locPoint else { return }
            guard let lat = listLoc[currentPlace]?.lat else { return }
            guard let lon = listLoc[currentPlace]?.lon else { return }
            guard let latitude = Double(lat) else { return }
            guard let longitude = Double(lon) else { return }
            //let span = MKCoordinateSpan(latitudeDelta: 0.002, longitudeDelta: 0.002)
            let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = name
            self.myMap.addAnnotation(annotation)
            currentPlace += 1
        }
    }

    
    /*
     * Pressing a cell performs a segue to the Detail view controller
     * An artwork is passed from the array so that its value pairs can be presented on the next view
     */
    var artPassed:Artwork? = nil
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentCell = indexPath.row
        self.artPassed = artOnSite[indexPath.section][indexPath.row]
        //print(artOnSite[indexPath.section][indexPath.row]?.locationNotes!)
        performSegue(withIdentifier: "toDetails", sender: nil)
    }
    
    /*
     * when a segue is performed through toDetails segue
     * set value of artReceived in DetailViewController class to the value of artPassed variable
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "toDetails" {
            let segVC = segue.destination as! DetailViewController
            segVC.artReceived = self.artPassed
        }
    }
    
    

}

private extension MKMapView {
    /* Take the initial location and centre the map view to it */
  func centerToLocation(_ location: CLLocation, regionRadius: CLLocationDistance = 150) {
    /* set coordinate location and the region radius passed from function parameteres */
    let initialRegion = MKCoordinateRegion(
      center: location.coordinate,
      latitudinalMeters: regionRadius,
      longitudinalMeters: regionRadius)
    /* set the region for the map view */
    setRegion(initialRegion, animated: true)
  }
}


