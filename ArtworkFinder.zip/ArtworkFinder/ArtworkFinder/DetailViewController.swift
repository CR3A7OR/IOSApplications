//
//  DetailViewController.swift
//  ArtworkFinder
//
//  Created by CR3A7OR on 05/01/2021.
//

//TO DO LIST
//
import UIKit

class DetailViewController: UIViewController {


    /* Relevant labels and text views to display information of specific artwork */
    @IBOutlet weak var navItem: UINavigationItem!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var artworkLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var infoView: UITextView!
    /* Object of type Artwork will store all data about specific artwork passed from segue*/
    var artReceived:Artwork? = nil
    
    /* Populate the labels with the correct information and use default values if value pair is empty*/
    override func viewDidLoad() {
        super.viewDidLoad()
        navItem.title = artReceived?.locationNotes ?? "unknown"
        titleLbl.text = "By \(artReceived?.artist ?? "unknown")"
        getImage()
        artworkLbl.text = artReceived?.title ?? "unknown"
        dateLbl.text = "Made in  \(artReceived?.yearOfWork ?? "unknown")"
        getImage()
        infoView.text = artReceived?.Information ?? "none"
        // Do any additional setup after loading the view.
    }
    
    /* Access url of images and then present one with the same filename as the value pair past from the segue  */
    func getImage() {
        let urlStringtemp = "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/artwork_images/\(artReceived?.fileName ?? "")"
        /* Remove all spaces in filename with %20 so that URLK is valid */
        let urlString = urlStringtemp.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        /* Convert type String to URL and retrieve data */
        guard let url = URL(string: urlString!) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            
            /* return if error is found */
            if error != nil {
                return
            }
            /* Return if status code is anything but 200 */
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("Error with URL provided")
                return
            }
            /* Populate the image view with the retrieved image file in the main queue */
            DispatchQueue.main.async {
                self.imageView.image = UIImage(data: data!)
            }
        }.resume()
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


