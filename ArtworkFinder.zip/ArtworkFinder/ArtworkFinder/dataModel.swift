//
//  dataModel.swift
//  ArtworkFinder
//
//  Created by CR3A7OR on 05/01/2021.
//

import Foundation

struct Artwork: Decodable {
    let id: String
    let title: String
    let artist: String
    let yearOfWork: String?
    let type: String?
    let Information: String?
    var lat: String
    var long: String
    var location: String
    let locationNotes: String?
    let fileName: String?
    let lastModified: String
    let enabled: String?
    
}
struct AllArtworks: Decodable {
    let artworks: [Artwork]    
}

struct Locations: Decodable {
    var title: String
    var lat: String
    var lon: String
    var locPoint: String
    var distance: Double
}


 
