//
//  CoreArts+CoreDataClass.swift
//  Assignment_2
//
//  Created by Halucha, Matthew on 11/01/2021.
//
//

import Foundation
import CoreData

@objc(CoreArts)
public class CoreArts: NSManagedObject {

}
