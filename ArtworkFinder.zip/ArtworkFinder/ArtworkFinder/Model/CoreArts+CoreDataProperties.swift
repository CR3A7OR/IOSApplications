//
//  CoreArts+CoreDataProperties.swift
//  Assignment_2
//
//  Created by Halucha, Matthew on 11/01/2021.
//
//

import Foundation
import CoreData


extension CoreArts {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CoreArts> {
        return NSFetchRequest<CoreArts>(entityName: "CoreArts")
    }

    @NSManaged public var artist: String?
    @NSManaged public var enabled: String?
    @NSManaged public var fileName: String?
    @NSManaged public var id: String?
    @NSManaged public var information: String?
    @NSManaged public var lastModified: String?
    @NSManaged public var lat: String?
    @NSManaged public var location: String?
    @NSManaged public var locationNotes: String?
    @NSManaged public var long: String?
    @NSManaged public var title: String?
    @NSManaged public var type: String?
    @NSManaged public var yearOfWork: String?

}

extension CoreArts : Identifiable {

}
