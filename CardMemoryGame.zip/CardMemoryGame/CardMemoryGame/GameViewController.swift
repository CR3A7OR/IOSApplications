//
//  GameViewController.swift
//  CardMemoryGame
//
//  Created by CR3A7OR on 24/11/2020.
//

import UIKit

class GameViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    /*
     * instantiate a context so we can access the core data through a view container
     */
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    /*
     * add an outlet for the collection view on the controller
     */
    @IBOutlet weak var cardCV: UICollectionView!

    /*
     * button pops view controller from stack and returns to menu view controller
     */
    @IBAction func returnBtn(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var score: UILabel!
    
    /*
     * function used to select a random card from the plist
     * creates an NSArray which contains values from plist
     * selects a random integer from the plist size
     * selects the card from array using the random integer as index and returns it
     */
    func loadcard() -> String {
        let path = Bundle.main.path(forResource: "cardList", ofType: "plist")
        let cards = NSArray(contentsOfFile: path!) as! [String]
        let random = Int(arc4random_uniform(UInt32(cards.count)))
        let card = cards[random]
        return card
    }

    /*
     * returns 30 cells
     */
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 30
    }
    
    /*
     * function which will populate each cell in the table view
     * instantiate variable as a cell from the collection view so we can change the view style, additionally we cast it so we can access outlets defined in our image class
     * takes now populated card array and selects a random index
     * sets front image preview as back of card and back image preview as card from random selected index
     * appends the card to a stored array and removes it from current array to prevent duplicates when selecting on the next cell
     */
    var cardArray = [String]()
    var storedArray = [String]()
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cardCV.dequeueReusableCell(withReuseIdentifier: "cardCell", for: indexPath) as! ImageCollectionViewCell
        /* if card state is flipped then flip it back to face back */
        if cell.flipped == true {
            cell.firstFlip()
        }
        let randomInt = Int.random(in: 0..<cardArray.count)
        cell.theImageBack.image = UIImage(named: "gray_back")
        cell.theImage.image = UIImage(named: cardArray[randomInt])
        storedArray.append(cardArray[randomInt])
        cardArray.remove(at: randomInt)
        return cell
    
    }
    /* variables and labels used to manage and show scores or track turns  */
    var cardNo = 0
    var indexs: [IndexPath] = []
    var scoreP1 = 0
    var flipCardCounter = 0
    var playerCount = 0
    var scoreP2 = 0
    @IBOutlet weak var tracking: UILabel!
    @IBOutlet weak var matchesFound: UILabel!
    @IBOutlet weak var matchesFoundp2: UILabel!
    /*
     * function is called everytime a cell is selected by use
     */
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        /* cell to update or change individual cards */
        let card1 = collectionView.cellForItem(at: indexPath) as? ImageCollectionViewCell
        
        /* if card selected is not flipped and it is first card selected then increment card selection counter and add indexPath number to array */
        if card1!.flipped == false && cardNo < 2 {
            if card1!.flipped == false {
                cardNo += 1
                indexs.append(indexPath)
                
            }
            /* flip card at indexPath */
            card1!.flip()
            /* if this is the second card selected */
            if cardNo == 2 {
                /* if the game is in two player mode */
                if twoPlayCheck == true {
                    /* if it player 1s turn then it is player 2s turn next so make the label colour red indicating their turn, else vice versa  */
                    if playerCount == 0 {
                        matchesFoundp2.textColor = UIColor.red
                        matchesFound.textColor = UIColor.black
                    }
                    else {
                        matchesFound.textColor = UIColor.red
                        matchesFoundp2.textColor = UIColor.black
                    }
                }
                /* call function to check if selected cards are equal */
                var checker = false
                checker = secondSlct()
                
                /* if the cards are equal then add points to player */
                if checker == true{
                    /*
                     * if the game is not in two player mode
                     * increment the player one score and increment the turn counter
                     * update both labels with the new values
                     */
                    if twoPlayCheck == false {
                        scoreP1 += 1
                        flipCardCounter += 1
                        /* if player score is 15 or turns counter has hit 30 then the game has reached the end state so we call the function */
                        if scoreP1 == 15 || flipCardCounter == 30 {
                            endState()
                        }
                        tracking.text = "Turns: \(flipCardCounter)"
                        matchesFound.text = "Player 1 Score: \(scoreP1)"
                    }
                    /* the game is in two polayer mode */
                    else {
                        /*
                         * check using if statement whos turn it is in the game, this is done with a counter
                         * increment the correct player's score value along with the turn counter
                         * update the correct labels with their new values
                         * change the player whos turn it is
                         */
                        if playerCount == 0 {
                            scoreP1 += 1
                            flipCardCounter += 1
                            /* if player score is 15 or turns counter has hit 30 then the game has reached the end state so we call the function */
                            if scoreP1 == 15 || flipCardCounter == 30 {
                                endState()
                            }
                            playerCount = 1
                            tracking.text = "Turns: \(flipCardCounter)"
                            matchesFound.text = "Player 1 Score: \(scoreP1)"
                        }
                        else{
                            scoreP2 += 1
                            flipCardCounter += 1
                            /* if player score is 15 or turns counter has hit 30 then the game has reached the end state so we call the function */
                            if scoreP2 == 15 || flipCardCounter == 30 {
                                endState()
                            }
                            playerCount = 0
                            tracking.text = "Turns: \(flipCardCounter)"
                            matchesFoundp2.text = "Player 2 Score: \(scoreP2)"
                        }
                    }
                    /* clear the index of what two cards have been selected */
                    indexs.removeAll()
                }
                /* if the cards are not equal  */
                else {
                    /* cell to update or change the cards at the stored index values in the array */
                    let card2 = collectionView.cellForItem(at: indexs[0]) as? ImageCollectionViewCell
                    let card3 = collectionView.cellForItem(at: indexs[1]) as? ImageCollectionViewCell
                    /* flip the cards back by calling the function */
                    card2!.flipBack()
                    card3!.flipBack()
                    /* increment turn counter and update label */
                    flipCardCounter += 1
                    tracking.text = "Turns: \(flipCardCounter)"
                    /* if player score is 15 or turns counter has hit 30 then the game has reached the end state so we call the function */
                    if scoreP2 == 15 || scoreP1 == 15 || flipCardCounter == 30 {
                        endState()
                    }
                    /* swap whos turn it is to play */
                    if playerCount == 0{
                        playerCount = 1
                    }
                    else { playerCount = 0}
                    /* clear the index of what two cards have been selected */
                    indexs.removeAll()
                }
   
            }
        }
    }
    
    /* function is called once the end of the game has been reached */
    func endState() {
        /*
         * if the game is not two player then retrieve high score from user defaults
         * Set a default title and message for the alert box
         * call function that creates alert box
         */
        if twoPlayCheck == false {
            let highScore = UserDefaults.standard.integer(forKey: "highScore")
            var title = "Game Finished"
            var msg = "Your score:  \(scoreP1) \nHighscore: \(highScore)"
            /* if player 1 socre is higher than retrieved high score then update the user default to the score and change message and title for alert box */
            if scoreP1 > highScore {
                UserDefaults.standard.set(scoreP1, forKey: "highScore")
                title = "CONGRATULATIONS"
                msg = "YOU HAVE A NEW HIGHSCORE:  \(scoreP1)"
            }
            createAlert(alrtTitle: title, msg: msg)
            scoreP2 = -1
        }
        else {
            /* game is in two player mode */
            var winner = ""
            let title = "Game Finished"
            /* if player 1 has more points, set winner message to player 1 */
            if scoreP1 > scoreP2 {
                 winner = "Player 1"
            }
            /* if both have the same points, set winner message to draw*/
            else if scoreP1 == scoreP2 {
                winner = "DRAW"
            }
            /* else player 2 has more points,  set winner message to player 2 */
            else {
                winner = "Player 2"
            }
            let msg = "WINNER IS: \(winner) \nPlayer 1 Score:  \(scoreP1) \nPlayer 2 Score: \(scoreP2)"
            createAlert(alrtTitle: title, msg: msg)
        }
        
        
        /* Saving results to CoreData by setting attributes */
        let savedScore = ScoreTracker(context: context)
        savedScore.player1 = Int64(scoreP1)
        savedScore.player2 = Int64(scoreP2)
        savedScore.dateLog = Date()
        do {
            try context.save()
        }catch{}
        

    }
    
    /*
     * instantiate an alert box with the passed title and message values
     * add two actions of playing again or returning to the main menu
     */
    func createAlert (alrtTitle: String, msg: String ) {
        let alert = UIAlertController(title: alrtTitle, message: msg, preferredStyle: UIAlertController.Style.alert)
        
        /* The collection view is reloaded and the stored array is cleared. The entire view controller is then reloaded to generate everything again */
        alert.addAction(UIAlertAction(title: "Play again", style: UIAlertAction.Style.default, handler: {action in
            self.cardCV.reloadData()
            self.storedArray.removeAll()
            self.viewDidLoad()
            
            }))
        
        /*  pops view controller from stack and returns to menu view controller */
        alert.addAction(UIAlertAction(title: "Menu", style: UIAlertAction.Style.default, handler: {action in
            self.navigationController?.popViewController(animated: true)
            self.dismiss(animated: true, completion: nil)
            }))
        
        /* present alert box to user */
        self.present(alert, animated: true, completion: nil)
        
    }
    
    /*
     * function checks if cards are the same or not and returns boolean
     * instantiates variable with card from array using index of user selected two cards
     * if values are equal pass back boolean as true else false
     * reset user selection value 
     */
    @objc func secondSlct() -> Bool {
        var checker = false
        let c1 = storedArray[indexs[0].row]
        let c2 = storedArray[indexs[1].row]
        if c1 == c2 {
           checker = true
        }
        else {
           checker = false
        }
        
        cardNo = 0
        
        return checker
    }
    
    //player 2 score label
    var multiPlay:String = "false"
    //determines game state using boolean
    var twoPlayCheck = true
    /*
     * reset all variables and labels so that the screen i a new game when view controller is launched
     * iterate 15 times and select a random card using loadcard() function
     * iterate through array each time card is selected to make sure it is not a duplicate
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        scoreP1 = 0
        scoreP2 = 0
        flipCardCounter = 0
        tracking.text = "Turns: 1"
        matchesFound.text = "Player 1 Score: 0"
        matchesFoundp2.text = "Player 2 Score: 0"
        /*
         * if passed variable contains value false then game is single player
         * hide player 2 score label and set checker boolean to false
         */
        if multiPlay == "false" {
            matchesFoundp2.isHidden = true
            twoPlayCheck = false
        }
        var i = 0
        var check = false
        while i < 15 {
            let tempCard = loadcard()
            for (index,_) in cardArray.enumerated() {
                if tempCard == cardArray[index]{
                    check = true
                    break
                }
                else {
                    check = false
                }
            }
           /* if card is not in array add it,  else pick another card through iteration without incrementing i */
            if check == false {
                cardArray.append(tempCard)
                i += 1
            }
        }
        /* duplicate values in array to create a pair of 15 */
        cardArray.append(contentsOf: cardArray)
        
    
        // Do any additional setup after loading the view.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
