//
//  ImageCollectionViewCell.swift
//  CardMemoryGame
//
//  Created by CR3A7OR on 24/11/2020.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {

    /*
     * image previews containing the front and back images of the cards
     */
    @IBOutlet weak var theImageBack: UIImageView!
    @IBOutlet weak var theImage: UIImageView!
    /*
     * boolean used to determine state of cards
     */
    var flipped = false
    
    /*
     * function called to flip a card when pressed
     * performs a view tranasition in the cell by flipping the front and back image previews
     * sets state of cards to flipped using boolean
     */
    func flip() {
            UIView.transition(from: self.theImageBack, to: self.theImage, duration: 0.5, options: [.transitionFlipFromRight, .showHideTransitionViews], completion: nil)
            flipped = true
    }
    
    /*
     * function called to flip a card when game is reset
     * performs a view tranasition in the cell by flipping the front and back image previews
     * sets state of cards from flipped using boolean
     */
    func firstFlip() {
            UIView.transition(from: self.theImage, to: self.theImageBack, duration: 0.25, options: [.transitionFlipFromRight, .showHideTransitionViews], completion: nil)
            flipped = false
    }
    
    /*
     * function called to flip the cards back once flipped
     * main queue is used to create a delay allowing the user to view the cards before they are flipped back
     * performs a view tranasition in the cell by flipping the front and back image previews
     * sets state of cards from flipped using boolean
     */
    func flipBack() {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+1.0){
            UIView.transition(from: self.theImage, to: self.theImageBack, duration: 0.5, options: [.transitionFlipFromRight, .showHideTransitionViews], completion: nil)
        }
        flipped = false
    }
    }
    
