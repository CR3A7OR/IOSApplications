//
//  LogViewController.swift
//  CardMemoryGame
//
//  Created by CR3A7OR on 29/11/2020.
//

import UIKit

class LogViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var logTable: UITableView!
    /*
     * creates an array of object type that will store core data
     * instantiate a context so we can access the core data through a view container
     */
    var scoreArray: [ScoreTracker] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let dateFrmt = DateFormatter()
    
    /*
     * button pops view controller from stack and returns to menu view controller
     */
    @IBAction func returnBtn(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    /*
     * returns a cell for each row in the array
     */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return scoreArray.count
    }
    
    /*
     * function which will populate each cell in the table view
     * instantiate a date format to be used
     * define a cell variable to later style the cells on the table
     * style the text of cell to show the date attribute from the array at current index using the date format previously established
     */
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        dateFrmt.dateFormat = "dd-MM-yyyy hh:mm"
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "logCell")
        cell.textLabel!.text = dateFrmt.string(from: ( scoreArray[indexPath.row]).value(forKey: "dateLog") as! Date)
        cell.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator
        return cell
    }
    
    /*
     * function is called everytime a cell is selected by user
     * instantiates player 1 and 2 score with object value found in array at selected index of table view, saves as integer
     * constructs message about final scores of selected game
     * generates an alert with the title of result and message
     * alert will present a close action that dismisses alert
     */
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let p1Score = scoreArray[indexPath.row].value(forKey: "player1") as! Int
        let p2Score = scoreArray[indexPath.row].value(forKey: "player2") as! Int
        let msg = "Player 1 Score: \(p1Score) \nPlayer 2 Score: \(p2Score)"
        
        let alert = UIAlertController(title: "Result", message: msg, preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Close", style: UIAlertAction.Style.default, handler: {action in
            
            }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    /*
     * calls fetch function everytime view is loaded
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        fetch()
        // Do any additional setup after loading the view.
    }
    
   /*
    * populates array with entity's objects from core data by calling fetch request function
    * reloads table view from main queue
    */
    func fetch() {
        do {
            self.scoreArray = try context.fetch(ScoreTracker.fetchRequest())
            DispatchQueue.main.async {
                self.logTable.reloadData()
            }
        }catch{}
    }
    
    //Remove logs swiping right to left "TESTING PURPOSES"
    /*
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let action = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completionHandler) in
        
        let scoreRemove = self.scoreArray[indexPath.row]
        self.context.delete(scoreRemove)
        
     
        do {
           try self.context.save()
        }catch {}
        self.fetch()
            
        }
        return UISwipeActionsConfiguration(actions: [action])
    }
     */
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
