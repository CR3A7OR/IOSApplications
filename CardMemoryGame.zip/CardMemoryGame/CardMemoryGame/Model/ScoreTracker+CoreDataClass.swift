//
//  ScoreTracker+CoreDataClass.swift
//  CardMemoryGame
//
//  Created by CR3A7OR on 28/11/2020.
//
//

import Foundation
import CoreData
//establishes core data class
@objc(ScoreTracker)
public class ScoreTracker: NSManagedObject {

}
