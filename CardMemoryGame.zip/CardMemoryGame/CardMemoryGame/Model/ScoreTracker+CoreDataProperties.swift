//
//  ScoreTracker+CoreDataProperties.swift
//  CardMemoryGame
//
//  Created by CR3A7OR on 28/11/2020.
//
//

import Foundation
import CoreData


extension ScoreTracker {
    //Function which can return objects from the core data
    @nonobjc public class func fetchRequest() -> NSFetchRequest<ScoreTracker> {
        return NSFetchRequest<ScoreTracker>(entityName: "ScoreTracker")
    }
    //defines all attributes in our core data as objects
    @NSManaged public var player1: Int64
    @NSManaged public var player2: Int64
    @NSManaged public var dateLog: Date?

}

extension ScoreTracker : Identifiable {

}
