//
//  ViewController.swift
//  CardMemoryGame
//
//  Created by CR3A7OR on 24/11/2020.
//

import UIKit

class ViewController: UIViewController {
    
    /*
     * pressing button performs a segue to the game view controller
     */
    @IBOutlet weak var gameTitle: UILabel!
    @IBAction func segBtn(_ sender: Any) {
      performSegue(withIdentifier: "mySegue", sender: self)
    }
    
    //will be used to display current highscore
    @IBOutlet weak var currentHighscore: UILabel?
    
    /*
     * pressing button performs a segue to the log view controller
     */
    @IBAction func logBtn(_ sender: Any) {
        performSegue(withIdentifier: "logSegue", sender: self)
    }
    
    /*
     * instantiate variable as empty string
     * pressing button performs a segue to game view controller but through a different segue
     * sets value of string to true
     */
    var twoPlayer:String = ""
    @IBAction func playersegBtn(_ sender: Any) {
        self.twoPlayer = "true"
        
    }
    
    /*
     * when a segue is performed through multiplayer segue
     * set value of multiplay in gameViewController class to the value of twoPlayer variable
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "multiSegue" {
            let gameVC = segue.destination as! GameViewController
            gameVC.multiPlay = self.twoPlayer
        }
    }
    
    /*
     * instantiate a user default variable used to store high score persistently
     */
    var highScore = UserDefaults.standard.integer(forKey: "highScore")

    /*
     * when viw controller starts up perform initial setups
     * assign variable as user default to store current high score
     * print high score to label to be shown as an informational feature
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        
         // Clear the High Score Value "TESTING PURPOSES"
         // UserDefaults.standard.set(0, forKey: "highScore")
         
        
        // Do any additional setup after loading the view.
        highScore = UserDefaults.standard.integer(forKey: "highScore")
        currentHighscore?.text = "Current Highscore: \(highScore)"
        
    }
    
    /*
     * when viw controller is opened onto screen
     * assign variable as user default to store current high score
     * print high score to label to be shown as an informational feature
     */
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        highScore = UserDefaults.standard.integer(forKey: "highScore")
        let test = highScore
        currentHighscore?.text = "Current Highscore: \(test)"
        
    }
    
    


}

